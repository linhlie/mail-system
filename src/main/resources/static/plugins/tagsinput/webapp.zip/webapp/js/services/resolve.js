/**
 * 画面遷移時の非同期処理 (=resolve)をまとめたモジュール
 */

'use strict';
angular.module('kyorituChatUiApp')
.provider('resolve', function() {
	
	//ユーザーの情報を取得する
	this.currentUser = {
			//currentUserとして遷移先のcontrollerでinjectする
            currentUser: ['$rootScope', '$q', '$http', '$location', '$window', function ($rootScope, $q, $http, $location, $window) { // 非同期でユーザー情報を取得する
                var d = $q.defer();
                if ($rootScope.currentUser) { // ユーザー情報を$rootScopeで保持している場合
                	if($rootScope.currentUser.userId === 9999999) {
                		$window.location.href= '#!/login';
                	}
                    d.resolve($rootScope.currentUser); // サーバーに問い合わせず終了
                } else {
                    $http.get('api/auth/getCurrentUser').then( // サーバーに問い合わせる
                        function (response) {
                            $rootScope.currentUser = response.data; //  ユーザー情報を$rootScopeにセット
                            if ($rootScope.currentUser) { // ユーザー情報がnullで無い場合
                                d.resolve($rootScope.currentUser); // 成功
                            } else {
                            	$rootScope.redirectPath = $location.url();
                            	$window.location.href= '#!/login'; // for some reason $location.path('/login') does not work here
                                d.reject(); // 失敗
                            }
                        },
                        function (response) {
                        	$rootScope.redirectPath = $location.url();
                        	$window.location.href= '#!/login';
                            d.reject(); // サーバー･エラーも失敗と見なす
                        }
                    );
                }
                return d.promise;
            }]
        };
	
	//ユーザーの情報を取得する
	//TODO: currentUserとの違いを調べ、必要に応じて統合する
	this.user = {
            user: ['$rootScope', '$q', '$http', '$window', function ($rootScope, $q, $http, $window) { // 非同期でユーザー情報を取得する
                var d = $q.defer();
                if ($rootScope.currentUser) { // ユーザー情報を$rootScopeで保持している場合
                    d.resolve($rootScope.currentUser); // サーバーに問い合わせず終了
                } else {
                    $http.get('api/auth/getCurrentUser').then( // サーバーに問い合わせる
                        function (response) {
                            $rootScope.currentUser = response.data; //  ユーザー情報を$rootScopeにセット
                            d.resolve($rootScope.currentUser); // 成功
                        },
                        function (response) {
                            d.reject(); // サーバー･エラーも失敗と見なす
                        }
                    );
                }
                return d.promise;
            }]
        };
	
    //ユーザーの情報を取得する
    //ペット情報や住所等、不足している情報がある場合は/profileに遷移させる
	this.currentUserWithChecks = {
			currentUser: ['$rootScope', '$q', '$http', '$location', '$window', function ($rootScope, $q, $http, $location, $window) { // 非同期でユーザー情報を取得する
            	var userChecks = function(currentUser, d) {
            		if (currentUser) { // ユーザー情報がnullで無い場合
                    	if($rootScope.currentUser.userId === 9999999) {
                    		$window.location.href= '#!/login';
                    		return;
                    	}
                    	if (currentUser.postalCode === null || typeof currentUser.postalCode === 'undefined' ||
                    		currentUser.latitude === null || typeof currentUser.latitude === 'undefined' ||
                    		currentUser.longitude === null || typeof currentUser.longitude === 'undefined') {
                    		$window.location.href= '#!/profile'; // for some reason $location.path('/profile') does not work here
                    		return;
                    	}

                    	// check pets!
                    	$http.post('api/pets/getUserPets', currentUser).then(function (response) {
                    		if (response.data && response.data.length > 0) {
                    			d.resolve(currentUser); // 成功
                    		} else {
                    			$window.location.href= '#!/profile'; // for some reason $location.path('/profile') does not work here
                    			return;
                    		}
                        }, function (response) {
                        	d.reject(); // 失敗
                        });
                    } else {
                        d.reject(); // 失敗
                    }
            	};

                var d = $q.defer();
                if ($rootScope.currentUser) { // ユーザー情報を$rootScopeで保持している場合
                	userChecks($rootScope.currentUser, d);
                } else {
                    $http.get('api/auth/getCurrentUser').then( // サーバーに問い合わせる
                        function (response) {
                            $rootScope.currentUser = response.data; //  ユーザー情報を$rootScopeにセット
                            userChecks($rootScope.currentUser, d);
                        },
                        function (response) {
                            d.reject(); // サーバー･エラーも失敗と見なす
                        }
                    );
                }
                return d.promise;
            }]
        };
	
	//ユーザーをゲストとして設定する
	this.setUserAsGuest = {
			//currentUserとして遷移先のcontrollerでinjectする
			currentUser: ['$rootScope', function ($rootScope) {
                return $rootScope.currentUser =
                {
                	  "userId" : 9999999,
                	  "address":"Example",
                	  "email":"example@example.com",
                	  "latitude":0,
                	  "loginAttempt":0,
                	  "longitude":0,
                	  "name":"guest",
                	  "postalCode":"000-0000",
                	  "rememberMe":false,
                	  "role":"USER",
                	  "shared":"0",
                }
            }]
        };
	
	//ユーザーのペット情報を取得する
    this.currentPet = {
		currentPet: ['$rootScope', '$q', '$http', function ($rootScope, $q, $http) {
            var d = $q.defer();
            if ($rootScope.currentPet) {
                d.resolve($rootScope.currentPet);
            } else if ($rootScope.currentUser) {
            	$http.get('api/pets/getUserPet').then(
                    function (response) {
                    	if(!response.status===204){
                        $rootScope.currentPet = response.data;
                    	}
                        if ($rootScope.currentPet) {
                            d.resolve($rootScope.currentPet);
                        } else {
                            $rootScope.currentPet = { userId: $rootScope.currentUser.userId };
                            // FIXME: should we d.reject();???
                            d.resolve($rootScope.currentPet);
                        }
                    },
                    function (response) {
                        d.reject();
                    }
                );
            } else {
                $rootScope.currentPet = { userId: $rootScope.currentUser.userId };
                d.resolve($rootScope.currentPet);
            }
            return d.promise;
        }]
	};
	
	
	//providerの定義に必須。おまじない。
	this.$get = function() {
		return 'resolve provider';
	};
});