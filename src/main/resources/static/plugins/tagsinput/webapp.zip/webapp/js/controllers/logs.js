'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:LogsCtrl
 * @description
 * # LogsCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
  .controller('LogsCtrl', ['$rootScope','$scope', '$http', 'currentUser', '$location', function ($rootScope, $scope, $http, currentUser, $location) {
	$rootScope.title = '受診予備チェック一覧';
	$rootScope.page = 'logs';
	var _this = this;
	
	_this.selectedPetId = "";
	_this.interviews_and_healthchecks = [];
	_this.petList = [];
	_this.currentUser = currentUser;
	_this.loading = true;
	if($rootScope.isFullpageCalled) {
		$.fn.fullpage.destroy('all');
	}
	
	//ユーザの問診票を取得
	$http.get('api/interviews/getUserInterviews', {
		params: {},
		headers : {'Accept' : 'application/json'}
	}).then(
		function (response) {
			_this.interviews_and_healthchecks = _this.interviews_and_healthchecks.concat(response.data);
		},
		function (response) {
			console.log(JSON.stringify(response));
		}
	);

	//ユーザのクイック健康チェック結果を取得
	$http.get('api/interviews/getUserHealthChecks', {
		params: {},
		headers : {'Accept' : 'application/json'}
	}).then(
		function (response) {
			// _this.healthchecks = response.data;
			_this.interviews_and_healthchecks = _this.interviews_and_healthchecks.concat(response.data);
		},
		function (response) {
			console.log(JSON.stringify(response));
		}
	);

	//ユーザのペット一覧を取得
	$http.post('api/pets/getUserPets', currentUser).then(function (response) {
		if (response.data && response.data.length > 0) {
			_this.petList = response.data;
			if(_this.petList) {
				_this.selectedPetId = _this.petList[_this.petList.length - 1].petId;
			}
		}
		_this.loading = false;
	}, function (response) {
		console.log(JSON.stringify(response));
		_this.loading = false;
		}
	);

	$scope.selectPet = function(id) {
		_this.selectedPetId = id;
	}

	// unixtimeを現地時刻に変換
	$scope.uxtimeToLocalTime = function(ts) {
		var d = new Date(ts);
		var offset = d.getTimezoneOffset();
		d.setHours(d.getHours() - offset/60);
		return d;
	}
	
	this.gotoHealthCheck = function() {
		$rootScope.selectedPetIdForCheck = _this.selectedPetId;
		$location.path('/health_check_survey'); // ログイン画面に遷移
	}
	
	this.gotoMedicalCheck = function() {
		$rootScope.selectedPetIdForCheck = _this.selectedPetId;
		$location.path('/medical_check_survey'); // ログイン画面に遷移
	}

}]);
