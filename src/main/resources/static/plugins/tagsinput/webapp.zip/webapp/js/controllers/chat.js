'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:ChatCtrl
 * @description
 * # ChatCtrl
 * Controller of the kyorituChatUiApp
 */

//センタリングを実行する関数
function centeringModalSyncer() {

	//画面(ウィンドウ)の幅、高さを取得
	var w = $( window ).width() ;
	var h = $( window ).height() ;

	// コンテンツ(.chat-modal-content)の幅、高さを取得
	// jQueryのバージョンによっては、引数[{margin:true}]を指定した時、不具合を起こします。
	var cw = $( ".chat-modal-content" ).outerWidth();
	var ch = $( ".chat-modal-content" ).outerHeight();

	//センタリングを実行する
	$( ".chat-modal-content" ).css( {"left": ((w - cw)/2) + "px","top": ((h - ch)/2) + "px"} ) ;

}

function scal(msg){
	$( this ).blur() ;	//ボタンからフォーカスを外す
	if( $( ".chat-modal-overlay" )[0] ) return false ;		//新しくモーダルウィンドウを起動しない
	//if($("#chat-modal-overlay")[0]) $("#chat-modal-overlay").remove() ;		//現在のモーダルウィンドウを削除して新しく起動する
	//オーバーレイを出現させる
	$( "body" ).append( '<div class="chat-modal-overlay"></div>' ) ;
	
	$( ".chat-modal-overlay" ).show();

	//コンテンツをセンタリングする
	centeringModalSyncer() ;

	//コンテンツをフェードインする
	$( ".chat-modal-content" ).show() ;
	
	//DOMを追加する
	$( ".chat-modal-content" ).append( msg );

	//[.chat-modal-overlay]、または[.chat-modal-close]をクリックしたら…
	$( ".chat-modal-overlay,.chat-modal-close" ).unbind().click( function(){

		//[.chat-modal-content]と[.chat-modal-overlay]をフェードアウトした後に…
		$( ".chat-modal-content,.chat-modal-overlay" ).hide();
		$( ".chat-modal-content" ).empty();
		$( ".chat-modal-overlay" ).remove() ;
	});
}

/* ### animationPattern1 ###
 * テキストを左から黒文字化する処理
 * <div id="id" class="animation"><div></div><img></div>の形式にて動作する
 */

function animationPattern1(argumentId)
{
	var animation = new AnimationContents({
		'elements': {
			'rootDom': $("#"+argumentId+".animation"),
			'elements': $('#'+argumentId+".animation").children()
			},
		'init': function( _el ) {
			initAnimation( _el );
		},
		'play': function( _el ) {
			playAnimation( _el );
		}
	});
	animation.execute();
	animation = null;
}

/* ### animationPattern1 ###
 *  addSpan text要素を1文字ずつ<span>で括る処理
 */
function addSpan( _dom )
{
	var $parent = $(_dom);
	$parent.contents().each( function( _i, _dom ) {
		var $text, $split;
		var text, split, i, len;
		if ( _dom.nodeType != 1 ) {
			$text = $(_dom);
			text = $text.text();
			len = text.length;
			split = '';
			for ( i = 0; i < len; i ++ ) {
				split += '<span>' + text.charAt(i) + '</span>';
			}
			$split = $( $.parseHTML( split ) );
			$split.insertAfter( _dom );
			$text.remove();
		}
	});
}
/** ### animationPattern1 ###
 * initAnimation 対象テキストの初期化処理
 */
function initAnimation( _el )
{
  var $rootDom = _el[ 'rootDom' ];
  var $elements = _el[ 'elements' ];

  $elements.each( function( _i, _dom ) {
    var $element = $(_dom);

    if ( ! $element.find( 'img' ).length ) {
      addSpan( _dom );
    }
  });
}

/** 
 * Anmate All Dom
 */
function playAnimation( _el )
{
  var $rootDom = _el[ 'rootDom' ];
  var $elements = _el[ 'elements' ];
  var i = 0;
  var max = $elements.length - 1;
  var $element = $elements.eq( i );
  (function() {
    var d = new $.Deferred;

    if ( $element.find( 'img' ).length ) {
      playImg( $element, d );
    }
    else {
      playText( $element, d );
    }
    return d.promise();
  })().
  then(function() {
    if ( i < max ) {
      playDom( $elements, i + 1, max );
    }
  });
}

/** ### animationPattern1 ###
 * playImg
 */
function playImg( _$element, _d )
{
  var $element = _$element;
  var $img = $element.find( 'img' ).eq(0);

  $img.
  css({
    'opacity': 0
  }).
  animate({
    'opacity': 1
  },{
    'duration': 400,
    'queue': false
  });

  $element.css({
    'text-indent': 0
  }).
  animate({
    'margin-top': -80
  },{
    'duration': 200,
    'easing': 'easeOutSine',
    'queue': true
  }).
  animate({
    'margin-top': 0
  },{
    'duration': 200,
    'easing': 'easeInSine',
    'queue': true,
    'complete': function() {
      _d.resolve();
    }
  });
}

/** ### animationPattern1 ###
 * DOMを処理する再帰関数
 */
function domIterator($span,span,max,i,_d) {
  return function callee(){
    $span.eq( i ).addClass( 'complete' );

    if ( i < max ) {
      i ++;
      setTimeout( function() {
        callee();
      }, span );
    }
    else {
      _d.resolve();
    }
  };
};

/** ### animationPattern1 ###
 * playText
 */
function playText( _$element, _d )
{
  var $element = _$element;
  var $span = $element.children( 'span' );
  var i = 0;
  var max = $span.length - 1;
  var span = 50;
  
  var itrator = domIterator($span,span,max,i,_d);
  itrator();
}


//-----------------------------------------------------
// class: AnimationContents
//-----------------------------------------------------

function AnimationContents( _setting )
{
  this.elements = _setting.elements;
  this.init = _setting.init;
  this.play = _setting.play;

  var top = $(window).scrollTop();

  this.complete = false;
  this.init( this.elements );

  return this;
}

AnimationContents.prototype.resize = function()
{
//  this.top = this.elements[ 'rootDom' ].offset().top;
};

AnimationContents.prototype.execute = function()
{
  if ( this.complete ) {
    return;
  }
else{
    this.complete = true;
    this.play( this.elements );
  }
};

angular.module('kyorituChatUiApp')
.controller('ChatCtrl', ['$rootScope','$scope', '$http', '$location', '$sce', 'currentUser', 'utilService',
function ($rootScope, $scope, $http, $location, $sce, currentUser, utilService) {
	$rootScope.title = '健康相談室';
	$rootScope.page = 'chat';

	/*
     * variables
     */
    this.context = null;
    this.q = '';
    this.qLabel = ''; // 値がある場合は、qに代わり画面に表示する
    this.talks = [];
    this.loading = false;
    this.selectMode = true;
    this.placeholder = '';
    var isGuestMode = (!currentUser.userId) || (currentUser.userId == '9999999');
    this.isGuestMode = isGuestMode;
    var inisialChatArea = 0;
    var isFirst = true;

    if (isGuestMode) {
    	function onChatBalloonHolmesReady($element) {
    		$element
				.find('.dh--chat__guestMode')
				.each(function(i, elem) {
					var $elem = angular.element(elem);
					$elem.removeClass('dh--chat__guestMode');
					if (checkFadeTarget($elem)) {
						addFadeEffect($elem);
					}
				});
        }
    	
    	var fadeTargetMinHeight = 42; // 回答コントロールの高さはこの値をこえるとグラデーション効果をつける
    	
    	function checkFadeTarget($element) {
    		var isToFade = false;
        	if ($element.find('ul').length > 0) {
        		isToFade = false;
        	} else if ($element.find('a').length > 0) {
        		isToFade = false;
        	} else if ($element.find('.mandatory').length > 0) {
        		isToFade = false;
        	} else if ($element.get(0).scrollHeight > fadeTargetMinHeight) {
        		isToFade = true;
        	} else {
        		isToFade = false;
        	}
        	return isToFade;
    	}
    	
    	function addFadeEffect($element) {
    		$element.addClass('dh--chat__fade-container');
    		$element.append("<div class='dh--chat__fade-mask'></div>");
    	} 
    	
        this.onChatBalloonHolmesReady = onChatBalloonHolmesReady;
    } else {
    	// 念のため追加
    	this.onChatBalloonHolmesReady = function(){};
    }
    
    /*
     * private functions
     */
    var _this = this;
    var addAnswer = function (answers) { // 応答を画面に表示する
    	if(isFirst){
    		inisialChatArea = $("#output-area").outerHeight();
    		isFirst = false;
    	}
    	if($("#output-area").outerHeight() > inisialChatArea){
    		isInit = false;
    	}
        var answer = answers.shift();
        if (answer) {
        	if (answer.answer.trim() !== '') {
        		if (isGuestMode) {
        			answer.answer = "<div class='dh--chat__guestMode'>" + answer.answer +
        					"</div>";
        		}
	            _this.talks.push({
	                answer: true, text: answer.answer, type: answer.type
	            });
        	}
        }
        if(!isInit){
        	scrollDown();
        }
        
        if (answers.length == 0) {
            changeSelectMode();
            return;
        }
        /* 表示すべき応答が残っている場合 */
        setTimeout(function () {
            $scope.$apply(function () {
                addAnswer(answers); // 処理を繰り返す
            });
        }, 1500);
    };
    var callback = function (response) { // サーバーからの戻りを処理する
        _this.loading = false;
        _this.context = response.data;

        // build answers
        var answers = [];
        var respAnswers = _this.context.answers;

        for (var i = 0; i < respAnswers.length; ++i) {
            var answerObj = respAnswers[i];
            var answerType = answerObj.answerType;
            var answerArr = answerObj.answer.split('\n'); // 改行でメッセージが区切られている

            for (var j = 0; j < answerArr.length; ++j) {
            	var answer = answerArr[j];
        		answers.push({
            		answer: answer,
            		type: answerType
            	});
            }
        }

        addAnswer(answers);
    };
    var callbackError = function (response) { // サーバーからのエラーの戻りを処理する
        _this.loading = false;
//        _this.context = null; // I think we should not reset the context, but this was original code from 小宮さん
        _this.disabled = true;
        if (response.data.messages) {
        	var messages = [];
        	var respMessages = response.data.messages;
        	for (var i = 0; i < respMessages.length; ++i) {
        		messages.push({
        			answer: respMessages[i],
        			type: 'MESSAGE'
        		});
        	}
            addAnswer(messages);
        }
    };

    var changeSelectMode = function () { // 画面上に選択肢が表示されている場合は質問の直接入力を許可しない
        setTimeout(function () {
            $scope.$apply(function () {
                if ($('.popover .mandatory').find('a, button:not(:disabled)').length) {
                    _this.selectMode = true;
                    _this.placeholder = '質問を選択してください。';
                    _this.q = '';
                	$('#text1').focusout();
                } else {
                    _this.selectMode = false;
                    _this.placeholder = '質問を入力してください。';
                    setTimeout(function () {
                    	$('#text1').focus();
                    }, 0);
                }
            });
        }, 1);
    };
    var scrollDown = function () { // 一番下までスクロール･ダウンする
        setTimeout(function () {
            var $area = $('body');
            $(window).scrollTop($area.get(0).scrollHeight);
        }, 1);
    };

    /*
     * init
     */
    //最初のメッセージはスクロールダウンしない
    var isInit = true;
    
    this.loading = true;
    $http.get('api/talk/get').then(
        function (response) {
            callback(response);
        },
        function (response) {
            callbackError(response);
        }
    );
    $scope.$on('$routeChangeStart', function(event, next, current) {
        $('#talk-template').off('click');
    });

    $('#talk-template').on('click', '.popover a:not([href], .feedback)', function (e) { // 選択肢を押下した時の処理
        e.preventDefault();
        var $target = $(e.target);
        /* submit */
        var question = $target.closest('a').attr('id') || $target.closest('a').text(); // a[class]が設定されている場合、img[alt]が設定されている場合は、それを用いる
        var qLabel = $target.closest('a').attr('class') ? $target.attr('alt') || $target.closest('a').text() : '';

        $scope.$apply(function () {
            _this.q = utilService.escapeHtml(question);
            _this.qLabel = utilService.escapeHtml(qLabel);
        });
        $scope.$apply(function () {
            _this.submit(question);
        });
    });
    
    $('#talk-template').on('click', '.popover .feedback', function (e) { // フィードバックを押下した時の処理
        e.preventDefault();
        var $target = $(e.target);
        $http.post('api/talk/feedback', { talkId: _this.context.variables._talkId, seq: $target.attr('href'), ok: $target.is('.ok') }).then(
            function (response) {
            	if($("#output-area").outerHeight() > inisialChatArea){
            		isInit = false;
            	}
                $target.addClass('active').siblings().removeClass('active');
            },
            function (response) {
                callbackError(response);
            }
        );
    });

    $('#talk-template').on('click', '.popover button', function (e) { // 問診のボタンを押下した時の処理
        e.preventDefault();
        var $button = $(e.target);
        var $form = $button.closest('form');
        var params = [];
        var checked = [];
        $form.find(':checkbox:checked').each(function () { params.push($(this).attr('name') + '=on') });
        $form.find(':checkbox:checked').each(function () { checked.push($(this).next('label').text()) });
        $form.find(':checkbox:not(:checked)').each(function () { params.push($(this).attr('name') + '=off') });
        var question = params.join('&');
        var qLabel = checked.join('<br/>');
        if(checked.length > 0){
	        $scope.$apply(function () {
	            //_this.q = question.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
	        	_this.q = utilService.xssReplace(question);
//	            _this.qLabel = qLabel.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
	            _this.qLabel = qLabel;
	        });
	        $scope.$apply(function () {
	            _this.submit();
	        });
        }
    });

    /*
     * 通常のボタンを押した時の処理
     */
    $('#talk-template').on('click', '.popover button.hiddenvalue', function (e) {
        e.preventDefault();
        var $button = $(e.target);
        var params = [];
        var question = $button.attr('value')
 	    $scope.$apply(function () {
//	        _this.q = question.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
 	    	_this.q = utilService.xssReplace(question);
//	        _this.qLabel = question.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
	        _this.qLabel = question;
	    });
	    $scope.$apply(function () {
	        _this.submit();
	    });
    });

    /*
     * チェックボックスの「これらに当てはまらない」の排他処理
     */
    // 「これらに当てはまらない」が押下された時
    $('#talk-template').on('click', 'input[type="checkbox"].none_box', function (e) {
        var $noneBox = $(e.target);
        if ($noneBox.prop('checked')){
        	    //$noneBox.parent().parent().find(":checkbox:not(.none_box)").each(function() {$(this).prop('checked', false);$(this).prop('disabled', true);});
        	    $noneBox.parent().parent().find(":checkbox:not(.none_box)").each(function() {$(this).prop('checked', false);});
        	    // 一旦全てをクリアしてnoneBoxをチェックする
        	    $noneBox.prop('checked', true);
        }else{
       	    //$noneBox.parent().parent().find(":checkbox:not(.none_box)").each(function() {$(this).prop('disabled', false);});
       	    	$noneBox.prop('checked', false);
        }
    });
    //「これらに当てはまらない」以外が押下された時
    $('#talk-template').on('click', 'input[type="checkbox"]:not(.none_box)', function (e) {
        var $checkBox = $(e.target);
    	    // noneBoxのチェックを外す
        	$checkBox.parent().parent().find(":checkbox.none_box").each(function() {$(this).prop('checked', false);});
    });

    /*
     * 画面下部のフォームにフォーカスするリンク
     */
    $('#talk-template').on('click', 'a.form_focus', function (e) {
    	    $('#text1').focus();
    });

    /*
     * functions
     */
    this.trustAsHTML = function (html) {
        return $sce.trustAsHtml(html);
    };
    this.submit = function (question) {
    	question = utilService.escapeHtml(question);
        if (this.submitForm.$invalid || this.loading) {
            return;
        }
        document.activeElement.blur();
        /* prevent click twice */
        $('#output-area').find('a:not([href], .feedback)').each(function () {
            var $this = $(this);
            var spanChange = $('<span>' + $this.html() + '</span>').addClass($this.attr('class') + ' disabled');
            $this.replaceWith(spanChange);
        });
        $('#output-area').find('form :input').prop('disabled', true).removeAttr('id');
        if (question === null || typeof question === 'undefined') {
        	question = this.q;
        }
        this.context.question = this.q;
        this.q = '';
        this.talks.push({ answer: false, text: this.qLabel ? this.qLabel : question });
        this.qLabel = '';
        if(!isInit){
        	scrollDown();
        }
        /* post */
        this.loading = true;
        $http.post('api/talk/post', this.context).then(
            function (response) {
            	if($("#output-area").outerHeight() > inisialChatArea){
            		isInit = false;
            	}
                callback(response);
            },
            function (response) {
                callbackError(response);
            }
        );
    };
    
	/* 画面サイズ変更時にモーダルをリサイズ*/
	$( window ).resize( centeringModalSyncer ) ;

	//ハンバーガーメニューのmouseleaveが発火 -> ハンバーガーメニューのclickが発火
//	$('nav[role="navigation"]').mouseleave(function(){
//		var a = document.getElementById("closeHamburgerMenu");
//		function triggerEvent(element, event) {
//			   if (document.createEvent) {
//			       // IE以外
//			       var evt = document.createEvent("HTMLEvents");
//			       evt.initEvent(event, true, true ); // event type, bubbling, cancelable
//			       return element.dispatchEvent(evt);
//			   } else {
//			       // IE
//			       var evt = document.createEventObject();
//			       return element.fireEvent("on"+event, evt)
//			   }
//			}
//		triggerEvent(a, 'click');
//		});

}]);
