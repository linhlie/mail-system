'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('MainCtrl', ['$scope','$rootScope', 'authService', function ($scope,$rootScope, authService) {

	$scope.logout = function () {
		authService.logout();
	};

	// For IE 11
//	$scope.menu = function () {
//		var ua = window.navigator.userAgent.toLowerCase();
//		console.log("実行");
//		if (ua.indexOf('msie') != -1 || ua.indexOf('trident') != -1) {
//			var nav = $('.bx--interior-left-nav-collapse');
//			nav.click();
//		}
//	};

	// 画面遷移時にハンバーガーメニューが開いていたら閉じる
	$scope.$on('$routeChangeSuccess', function () {
		if ($('.bx--interior-left-nav').attr('data-collapsed') == 'false') {
			var nav = $('.bx--interior-left-nav-collapse');
			nav.click();
		}
		window.scrollTo(0, 0); //画面遷移時に最上部にスクロール
	});

	// ハンバーガーメニューが開いているときに画面のどこかをタップしたら閉じる
	$(document).on('click', function(e) {
		if ($('.bx--interior-left-nav').attr('data-collapsed') == 'false' && !$(e.target).closest('.bx--interior-left-nav').length) {
			var nav = $('.bx--interior-left-nav-collapse');
			nav.click();
		}
	});
	authService.currentUser();
}]);
