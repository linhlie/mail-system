/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:MedicalCheckSurveyCtrl
 * @description
 * # MedicalCheckSurveyCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
  .controller('MedicalCheckSurveyCtrl', ['$rootScope', '$scope', '$http', '$location', 'currentUser', '$routeParams',  function ($rootScope, $scope, $http, $location, currentUser, $routeParams) {
	$rootScope.title = '受診予備チェック';
	$rootScope.page = 'medical_check_survey';
	let submitAnswers ={}; 
	if(!$rootScope.selectedPetIdForCheck) {
		console.log('ペットを選択してください');
		$location.path('/logs/');
	}
	$scope.loading = true;
	submitAnswers.petId = $rootScope.selectedPetIdForCheck;
	$rootScope.selectedPetIdForCheck = '';
	this.SURVEY_TEXT_MAX = 125;
	this.answers ={};
	this.answers.cg1 = false;
	this.answers.cg2 = false;
	this.answers.cg3 = false;
	this.answers.cg4 = false;
	this.answers.cg5 = false;
	this.answers.cg6 = false;
	this.answers.cg7 = false;
	this.answers.cg8 = false;
	this.answers.cg9 = false;
	this.answers.cg10 = false;
	this.answers.cg11 = false;
	this.answers.skin1 = false;
	this.answers.skin2 = false;
	this.answers.skin3 = false;
	this.answers.skin4 = false;
	this.answers.skin5 = false;
	this.answers.skinComment = '';
	this.answers.eyesEnt1 = false;
	this.answers.eyesEnt2 = false;
	this.answers.eyesEnt3 = false;
	this.answers.eyesEnt4 = false;
	this.answers.eyesEnt5 = false;
	this.answers.eyesEnt6 = false;
	this.answers.eyesEnt7 = false;
	this.answers.eyesEnt8 = false;
	this.answers.eyesEnt9 = false;
	this.answers.eyesEnt10 = false;
	this.answers.eyesEnt11 = false;
	this.answers.eyesEnt12 = false;
	this.answers.eyesEnt13 = false;
	this.answers.eyesEnt14 = false;
	this.answers.eyesComment = '';
	this.answers.skeletal1 = false;
	this.answers.skeletal2 = false;
	this.answers.skeletal3 = false;
	this.answers.skeletal4 = false;
	this.answers.skeletalComment = '';
	this.answers.cardiovascular1 = false;
	this.answers.cardiovascular2 = false;
	this.answers.cardiovascular3 = false;
	this.answers.cardiovascularComment1 = '';
	this.answers.cardiovascular4 = false;
	this.answers.cardiovascular5 = false;
	this.answers.cardiovascular6 = false;
	this.answers.cardiovascularComment2 = '';
	this.answers.respiratory1 = false;
	this.answers.respiratory2 = false;
	this.answers.respiratory3 = false;
	this.answers.respiratory4 = false;
	this.answers.respiratory5 = false;
	this.answers.respiratoryComment = '';
	this.answers.digestive1 = false;
	this.answers.digestive2 = false;
	this.answers.digestive3 = false;
	this.answers.digestive4 = false;
	this.answers.digestiveComment1 = '';
	this.answers.digestive5 = false;
	this.answers.digestive6 = false;
	this.answers.digestive7 = false;
	this.answers.digestive8 = false;
	this.answers.digestive9 = false;
	this.answers.digestiveComment2 = '';
	this.answers.urogenital1 = false;
	this.answers.urogenital2 = false;
	this.answers.urogenital3 = false;
	this.answers.urogenital4 = false;
	this.answers.urogenital5 = false;
	this.answers.urogenital6 = false;
	this.answers.urogenital7 = false;
	this.answers.urogenitalComment1 = '';
	this.answers.urogenital8 = false;
	this.answers.urogenital9 = false;
	this.answers.urogenitalComment2 = '';
	this.answers.urogenitalComment3 = '';
	this.answers.nervous1 = false;
	this.answers.nervous2 = false;
	this.answers.nervous3 = false;
	this.answers.nervous4 = false;
	this.answers.nervous5 = false;
	this.answers.nervousComment = '';
	
	this.backTologs = function() {
		$location.path('/logs/');
	}
	
	$(document).ready(function(){
		if($rootScope.isFullpageCalled) {
			$.fn.fullpage.destroy('all');
		}
			$('#fullpage').fullpage({
				//スワイプによる質問の遷移を禁止
				touchSensitivity: 999999999,
				afterRender: function(){
					$scope.$apply(function () {
						$scope.loading = false;
					});
				}
			});
			$rootScope.isFullpageCalled = true;
		});

	//次へがクリックされたら、fullPage.jsの横スクロールを発火
	$('.next').on('click',function(){
		$(".fp-next").click();
	});

	//戻るがクリックされたら、fullPage.jsの横スクロールを発火
	$('.prev').on('click',function(){
		$(".fp-prev").click();
	});
	
	this.submitSurvey = function() {
		this.answers.eyesEnt10 = this.answers.cardiovascular1;
		this.answers.eyesEnt11 = this.answers.respiratory1;
		this.answers.eyesEnt12 = this.answers.respiratory3;
		this.answers.eyesEnt13 = this.answers.respiratory4;
		this.answers.eyesEnt14 = this.answers.respiratory5;
		this.answers.nervous1 = this.answers.cardiovascular2;
		this.answers.nervous3 = this.answers.skeletal4;
		this.answers.petId = submitAnswers.petId;
		
		if(!this.buttonClicked) {
			//「送信」ボタンのクリックを１回に制御
			this.buttonClicked = true;
			$http.post('api/interviews/createInterview', this.answers).then(function (response) {
				if(!response.data.success) {
					console.log('health check insert error');
				} else {
					$http.get('api/interviews/getUserInterviews').then(function (response) {
						$location.path('/medical_check_assessment/' + response.data[0].interviewId);
					});
				}
		    });
		}
	}
}]);