'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:AccountCtrl
 * @description
 * # AccountCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('AccountCtrl',['$rootScope', '$scope', '$http', '$routeParams', '$location', 'currentUser', function ($rootScope, $scope, $http, $routeParams, $location, currentUser) {
	$rootScope.title = 'アカウント設定';
	$rootScope.page = 'account';
}]);
