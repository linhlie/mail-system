'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:UserEmailChangeController
 * @description
 * # PetCtrl2
 * Controller of the UserEmailChangeController
 */
angular.module('kyorituChatUiApp')
.controller('deleteAccountController', ['$scope', '$http', '$location', 'currentUser', '$rootScope', function ($scope, $http, $location, currentUser, $rootScope) {  
	$rootScope.title = '退会手続き';
	$rootScope.page = 'delete_account';
	
	var _this = this;
	this.user = currentUser;

	this.deleteUser = function() {
		$scope.waiting = true;
		_this.messages = [];
		$http.post('api/auth/deleteUserAccount', _this.user).then(function (response) {
			$scope.waiting = false;
			_this.hasErrors = false;
			$rootScope.currentUser = null;
    		$location.path('/delete_account_complete');
        }, function (response) {
        	// error
        	$scope.waiting = false;
        	_this.messages = response.data.messages;
        	_this.hasErrors = true;
        });
	}
	this.logout = function () {authService.logout();};

}]);
