'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:InterviewCtrl
 * @description
 * # InterviewCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
  .controller('InterviewCtrl', ['$scope', function ($scope) {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
    
  $scope.cards = [
      {name: 'q1', symbol: '今まで入院するような大きな病気にかかったことがありますか？'},
      {name: 'q2', symbol: '今までに手術を受けたことがありますか？'},
      {name: 'q3', symbol: '今までに輸血を受けたことがありますか？'},
      {name: 'q4', symbol: '今までに生活習慣病を指摘されたことがありますか？'}
  ];

  //NOの場合の処理
  $scope.swipeLeft = function (index) {
      var viewport = document.getElementById('viewport');
      var li = viewport.getElementsByTagName('li');
      angular.element(li).eq(li.length-1).remove();
      $scope.cards.splice(index, 1);
  };

  //YESの場合の処理
  $scope.swipeRight = function (index) {
      var viewport = document.getElementById('viewport');
      var li = viewport.getElementsByTagName('li');
      angular.element(li).eq(li.length-1).remove();
      $scope.cards.splice(index, 1);
  };
//
//  $scope.dragend = function (index,eventName, eventObject) {
//      console.log('dragend', eventObject);
//      if($scope.isThrowOut) {
//        if($scope.options.throwOutConfidence < 1){
//          $scope.throwoutleft(index,eventName, eventObject);
//        }else{
//          $scope.throwoutright(index,eventName, eventObject);
//        }
//      };
//  };
  $scope.swipeNo = function (){
    $scope.swipeLeft(0);
  };
  $scope.swipeYes = function (){
    $scope.swipeRight(0);
  };
//  $scope.options = {
//      throwOutConfidence: function (offset, elementWidth) {
////          console.log('throwOutConfidence', offset, elementWidth);
//          return Math.min(Math.abs(offset) / elementWidth, 1);
//      },
//      isThrowOut: function (offset, elementWidth, throwOutConfidence) {
//          console.log('isThrowOut', offset, elementWidth, throwOutConfidence);
//          return throwOutConfidence === 1;
//      }
//  };
}]);
