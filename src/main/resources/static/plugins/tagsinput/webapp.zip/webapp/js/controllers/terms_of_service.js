'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:termsOfServiceController
 * @description
 * # termsOfServiceController
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('termsOfServiceController',['$rootScope', '$scope', '$window', function ($rootScope, $scope, $window) {
	$rootScope.title = '利用規約';
	$rootScope.page = 'terms_of_service';
	$window.scrollTo(0, 0);
}]);
