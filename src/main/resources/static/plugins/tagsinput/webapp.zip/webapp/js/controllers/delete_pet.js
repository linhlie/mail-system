'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:UserEmailChangeController
 * @description
 * # PetCtrl2
 * Controller of the UserEmailChangeController
 */
angular.module('kyorituChatUiApp')
.controller('deletePetCtrl', ['$scope', '$http', '$location', 'currentPet', '$rootScope', function ($scope, $http, $location, currentPet, $rootScope) {  
	$rootScope.title = 'ペット情報削除';
	$rootScope.page = 'delete_pet';
	
	var _this = this;
	this.pet = currentPet;
	
  	_this.submitPet = function() {
		//call api to update
		_this.pet.petValid = 0;
  		$http.post('api/pets/createOrUpdatePet', _this.pet).then(function (response) {
  				$location.path('/profile');
//  				_this.messages = response.data.messages;
//  				_this.hasErrors = false;
  	    }, function (response) {
//  	        	_this.messages = response.data.messages;
//  				_this.hasErrors = true;
  	    });
	}

}]);
