'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:UserEmailChangeController
 * @description
 * # PetCtrl2
 * Controller of the UserEmailChangeController
 */
angular.module('kyorituChatUiApp')
.controller('UserEmailChangeController', ['$rootScope', '$scope', '$http', '$location', 'currentUser', function ($rootScope, $scope, $http, $location, currentUser) {
	$rootScope.title = 'メールアドレス変更';
	$rootScope.page = 'user_email_change';
	var _this = this;
	_this.currentUser = currentUser;
	_this.message;
	this.hasErrors = false;
	_this.tempEmail = currentUser.email;
	$scope.waiting = false;

	this.submitUserEmail = function() {
		if ($scope.waiting) {
    		return;
    	};
    	$scope.waiting = true;
		this.hasErrors = false;
		_this.messages = null;
		_this.tempEmail = this.tempEmail;
		if (_this.tempEmail === _this.currentUser.email) {
			_this.message = "メールアドレスが変更されていません。";
			_this.messages= [_this.message];
			this.hasErrors = true;
			$scope.waiting = false;
			return; // do we need to display a message here?
		}
		if (!validateEmail(_this.tempEmail)) {
			_this.message = "変更に失敗しました。入力したメールアドレスをご確認ください。";
			_this.messages = [_this.message];
			this.hasErrors = true;
			$scope.waiting = false;
			return;
		}
		$http.post('api/auth/updateTempEmail', {
			tempEmail: _this.tempEmail,
			email: _this.currentUser.email,
			userId: _this.currentUser.userId
		}).then(function (response) {
			if (response.data.success) {
				_this.messages = ['ご入力いただいたメールアドレスにメールを送信しました。メールアドレス変更を完了させるためには、届いたメール内のリンクをクリックしてください。'];
				_this.hasErrors = false;
			} else {
				_this.messages = response.data.messages;
				_this.hasErrors = true;
				$scope.waiting = false;
			}
        }, function (response) {
        	// error
        	_this.messages = response.data.messages;
        	_this.hasErrors = true;
        	$scope.waiting = false;
        });
	}

	// メールアドレスのバリデーションチェック
	var validateEmail = function(email) {
		// 未入力の場合はfalseを返す
		if (email == null) {
			return false;
		}
		// HTML5のメールアドレスチェック用の正規表現と合わせた. 正しければtrue,そうでなければfalseを返す.
		return email.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/) !== null;
	}

	this.close = function (idx, arr) { arr.splice(idx, 1) }
}]);
