'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:LoginCtrl
 * @description
 * # LoginCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('LoginCtrl', ['$scope', '$http', '$location', '$rootScope', '$window',
function ($scope, $http, $location, $rootScope, $window) {
	$rootScope.title = 'ログイン';
	$rootScope.page = 'login';
	var _this = this;
	$rootScope.currentUser = null; // $rootScopeで保持しているユーザー情報をクリア
	this.user = this.user || {};
    this.user.rememberMe = true; // Remember meをdefaultでtrueとし、画面上からもcheckboxを削除する
    this.messages = [];
    this.hasErrors = false;
    $scope.waiting = false;

    if (window.message) { // main.jspにメッセージがセットされている場合
    	this.message = window.message[0]; // 詰め替えて
        window.message = null; // main.jspのメッセージを削除
        $('#modalBtn').click();
    }

    this.login = function () {
    	_this.hasErrors = false;
    	_this.messages = [];
        if (this.loginForm.$invalid) {
            return;
        }
        $scope.waiting = true;
        $http.post('api/auth/login', this.user).then(
            (function (response) {
            	$scope.waiting = false;
                if (response.data.success) { // ログインに成功した場合
                	$http.get('api/auth/getCurrentUser').then(
                        function (response) {
                            $rootScope.currentUser = response.data;
                            // if we had a pending
                            if ($rootScope.redirectPath && $rootScope.redirectPath !== null && $rootScope.redirectPath.trim() !== '') {
                            	var redirectUrl = $rootScope.redirectPath;
                            	$rootScope.redirectPath = null;
                            	$window.location.href = '#!' + redirectUrl;
                            } else {
                            	$location.path('/home');
                            }
                        },
                        function (response) {
                        	$location.path('/');
                        }
                    );
                } else {
                	_this.hasErrors = true;
                    this.messages = response.data.messages;
                }
            }).bind(this),
            (function (response) {
            	$scope.waiting = false;
            	_this.hasErrors = true;
                this.messages = response.data.messages;
            }).bind(this)
        );
    };

    this.close = function (idx, arr) { arr.splice(idx, 1) };
    
    this.openEmailError = function () {
    	if(this.loginForm.email.$error.email){
    	$scope.emailError = true;
    	}
    }
    
    this.closeEmailError = function () {
    	$scope.emailError = false;
    }
    
}]);