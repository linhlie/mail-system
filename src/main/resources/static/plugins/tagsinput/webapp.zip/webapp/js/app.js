'use strict';

/**
 * @ngdoc overview
 * @name kyorituChatUiApp
 * @description
 * # kyorituChatUiApp
 *
 * Main module of the application.
 */
angular
  .module('kyorituChatUiApp', [
    'ngAnimate',
    'ngCookies',
    'ngMessages',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'gajus.swing',
    'slickCarousel'
  ])
  .run(['$rootScope', '$location', function ($rootScope, $location) {
        $rootScope.$on("$routeChangeError", function () { // ユーザー情報取得の失敗のみを想定
            $location.hash($location.path()); // ログイン後に遷移するようpathをhashに保持しておく
            $location.path('/'); // ログイン画面に遷移
        });
    }]) //
    .config(['$httpProvider', '$sceDelegateProvider', function($httpProvider, $sceDelegateProvider) {
    	//initialize get if not there
    	if (!$httpProvider.defaults.headers.get) {
    		$httpProvider.defaults.headers.get = {};
    	}
    	//disable IE ajax request caching
    	$httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
    	$httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache, no-store, must-revalidate';
    	$httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
    	$httpProvider.defaults.cache = false;
	}])
	.config(['$routeProvider', 'resolveProvider', function ($routeProvider, resolveProvider) {

	    $routeProvider
	      .when('/', {
		    template: '',
		    controller: 'RootCtrl',
		    controllerAs: 'root',
		    resolve: resolveProvider.user
		  })
	      .when('/about', {
	        templateUrl: 'views/about.html',
	        controller: 'AboutCtrl',
	        controllerAs: 'about'
	      })
	      .when('/chat', {
	        templateUrl: 'views/chat.html',
	        controller: 'ChatCtrl',
	        controllerAs: 'chatCtrl',
	        resolve: resolveProvider.currentUserWithChecks
	      })
	      .when('/chat2', {
	        templateUrl: 'views/chat.html',
	        controller: 'ChatCtrl',
	        controllerAs: 'chatCtrl',
	        resolve: resolveProvider.setUserAsGuest
	      })
	      .when('/profile', {
	        templateUrl: 'views/profile.html',
	        controller: 'ProfileCtrl',
	        controllerAs: 'profileCtrl',
	        resolve: resolveProvider.currentUser
	      })
	      .when('/login', {
	        templateUrl: 'views/login.html',
	        controller: 'LoginCtrl',
	        controllerAs: 'loginCtrl'
	      })
	      .when('/singup', {
	        templateUrl: 'views/signup.html',
	        controller: 'SignupCtrl',
	        controllerAs: 'signupCtrl'
	      })
	      .when('/register/:digest', {
	        templateUrl: 'views/register.html',
	        controller: 'RegisterCtrl',
	        controllerAs: 'registerCtrl'
	      })
	      .when('/forgot_password', { // パスワード変更メールを送信するためにアドレスを入力する画面
	        templateUrl: 'views/forgot_password.html',
	        controller: 'ForgotPasswordCtrl',
	        controllerAs: 'forgotPasswordCtrl'
	      })
	      .when('/forgot/:digest', { // メールから遷移してきた際のパスワード変更画面
	    	templateUrl: 'views/forgot.html',
            controller: 'ForgotController',
            controllerAs: 'forgotCtrl'
          })
          .when('/user_password_change', { // ログイン後のメニューからパスワード変更する際の画面
	    	templateUrl: 'views/user_password_change.html',
            controller: 'UserPasswordChangeController',
            controllerAs: 'upcCtrl',
            resolve: resolveProvider.currentUser
          })
          .when('/user_email_change', { // ログイン後のメニューからメールアドレス変更する際の画面
	    	templateUrl: 'views/user_email_change.html',
            controller: 'UserEmailChangeController',
            controllerAs: 'uecCtrl',
            resolve: resolveProvider.currentUser
          })
          .when('/?dg=:digest', { // メールアドレス変更メールから遷移して来た際の画面
	    	templateUrl: 'views/front.html',
	    	controller: 'FrontCtrl',
	        controllerAs: 'front',
	        resolve: resolveProvider.user
          })
	      .when('/logs', {
	        templateUrl: 'views/logs.html',
	        controller: 'LogsCtrl',
	        controllerAs: 'lCtrl',
	        resolve: resolveProvider.currentUserWithChecks
	      })
	      .when('/pet', {
	        templateUrl: 'views/pet.html',
	        controller: 'PetCtrl',
	        controllerAs: 'petCtrl',
	        resolve: resolveProvider.currentPet
	      })
        .when('/register_image', {
	        templateUrl: 'views/register_image.html',
	        controller: 'registerImageController',
	        controllerAs: 'registerImageCtrl',
            resolve: resolveProvider.currentPet
	      })
	      .when('/delete_pet', {
	        templateUrl: 'views/delete_pet.html',
	        controller: 'deletePetCtrl',
	        controllerAs: 'dpCtrl',
	        resolve: resolveProvider.currentPet
	      })
	      .when('/detail/:interview_id', {
	        templateUrl: 'views/detail.html',
	        controller: 'DetailCtrl',
	        controllerAs: 'detail',
	        resolve: resolveProvider.currentUser
	      })
	      .when('/front', {
	        templateUrl: 'views/front.html',
	        controller: 'FrontCtrl',
	        controllerAs: 'front',
	        resolve: resolveProvider.user
	      })
	      .when('/health_check_survey', {
	        templateUrl: 'views/health_check_survey.html',
	        controller: 'HealthCheckSurveyCtrl',
	        controllerAs: 'hcsurvey',
	        resolve: resolveProvider.currentUser
	      })
	      .when('/medical_check_survey', {
	        templateUrl: 'views/medical_check_survey.html',
	        controller: 'MedicalCheckSurveyCtrl',
	        controllerAs: 'mcsurvey',
	        resolve: resolveProvider.currentUser
	      })
	      .when('/health_check_detail/:healthcheck_id', {
	        templateUrl: 'views/health_check_detail.html',
	        controller: 'HealthCheckDetailCtrl',
	        controllerAs: 'hcdetail',
	        resolve: resolveProvider.currentUser
	      })
	      .when('/health_check_assessment/:healthcheck_id', {
	        templateUrl: 'views/health_check_assessment.html',
	        controller: 'HealthCheckAssessmentCtrl',
	        controllerAs: 'hcassessment',
	        resolve: resolveProvider.currentUser
	      })
	      .when('/medical_check_assessment/:interview_id', {
	        templateUrl: 'views/medical_check_assessment.html',
	        controller: 'MedicalCheckAssessmentCtrl',
	        controllerAs: 'mcassessment',
	        resolve: resolveProvider.currentUser
	      })
//	      .when('/account', {
//	        templateUrl: 'views/account.html',
//	        controller: 'AccountCtrl',
//	        controllerAs: 'accountCtrl',
//	        resolve: resolveProvider.currentUser
//	      })
  	      .when('/delete_account', {
	        templateUrl: 'views/delete_account.html',
	        controller: 'deleteAccountController',
	        controllerAs: 'daCtrl',
	        resolve: resolveProvider.currentUser
	      })
	      .when('/delete_account_complete', {
	        templateUrl: 'views/delete_account_complete.html',
        	controller: 'deleteAccountCompleteController',
	        controllerAs: 'dapCtrl',
	      })
  	      .when('/privacy_policy', {
	        templateUrl: 'views/privacy_policy.html',
	        controller: 'privacyPolicyController'
	      })
  	      .when('/terms_of_service', {
	        templateUrl: 'views/terms_of_service.html',
	        controller: 'termsOfServiceController'
	      })
	      .when('/link', {
	        templateUrl: 'views/link.html',
	        controller: 'linkController',
	        controllerAs: 'linkCtrl',
	      })
	      .when('/home', {
	    	templateUrl: 'views/home.html',
	    	controller: 'homeController',
	    	resolve: resolveProvider.currentUserWithChecks
	      })
	      .otherwise({
	        redirectTo: '/'
	      });
	}]);

