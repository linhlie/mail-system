'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
