'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:rootCtrl
 * @description
 * # RootCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('RootCtrl', ['$rootScope','$scope', '$http', '$routeParams', '$location', 'user' ,function ($rootScope, $scope, $http, $routeParams, $location, user) {
	$rootScope.title = 'AI Drホームズの健康相談室';
	$rootScope.page = 'root';
	var _this = this;
	_this.user = user;
	if(_this.user==""){
		$location.path('/front');
	} else {
		$location.path('/home');
	}
}]);