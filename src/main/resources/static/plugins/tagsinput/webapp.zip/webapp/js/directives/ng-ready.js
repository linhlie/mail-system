/**
 * TODO: ディレクティブの説明を記載
 */

'use strict';
angular.module('kyorituChatUiApp')
    .directive('ngReady',function() {
    	return function (scope, element, attrs) {
            element.ready(function() {
            	scope.$apply(function () {
                    scope.$eval(attrs.ngReady, {element: element});
                });
            });
        };
    });