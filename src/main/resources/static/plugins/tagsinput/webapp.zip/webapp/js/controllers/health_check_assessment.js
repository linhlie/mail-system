'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:HealthCheckAssessmentCtrl
 * @description
 * # HealthCheckAssessmentCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('HealthCheckAssessmentCtrl',  ['$rootScope', '$scope', '$http', '$location', 'currentUser', '$routeParams',  function ($rootScope, $scope, $http, $location, currentUser, $routeParams) {
	$rootScope.title = '健康チェック結果画面';
	$rootScope.page = 'health_check_assessment';
	var _this = this;
	_this.healthcheckId = $routeParams.healthcheck_id;
	_this.message = '健康チェック結果を取得しています...';
	_this.isModalOpen = false;
	
	//fullpage.jsを破棄してスクロールを有効化
	if($rootScope.isFullpageCalled) {
		$.fn.fullpage.destroy('all');
	}
	
	var urgencyMessageMap = {
		'高': 'ちょっと言いにくいのですが、いま教えてくれた内容から考えると体調が良くないみたいです・・・<br>' +
				'かかりつけの病院に行って、病気にかかっていないか早めに病院で検査してもらった方が良いですよ。',
		'中': 'いま教えてくれた内容から考えると、緊急の問題は無いみたいですが、気になる点が何点かあります・・・<br>' +
				'動物病院で身体検査をしないと分からないこともたくさんあるので、近いうちに、かかりつけの動物病院で検査してもらった方が安心です。',
		'低': '回答からは、特に問題は無さそうに思えるのですが、<br>' +
				'動物病院で身体検査をしないと分からないこともたくさんあるので、近いうちに、かかりつけの動物病院で検査してもらった方が安心です。',
	};
	
	//ユーザの問診票を取得し、該当アセスメント結果を表示
	$http.get('api/interviews/getHealthCheck', {
		params: {
			healthcheck_id: _this.healthcheckId
		},
		headers : {'Accept' : 'application/json'}
		}).then(
			function (response) {
				var urgency = response.data.urgency;
				var message = urgencyMessageMap[urgency];
				if (!message) {
					message = 'えぇっと、わかならい健診結果になります。管理員に連絡してください。<br>' +
							'URGENCY = ' + urgency; // メッセージの既定値
				}
				_this.message = message;
			},
			function (response) {
				_this.message = '健康チェック結果の取得に失敗しました。';
				console.log(JSON.stringify(response));
			}
		);
}]);