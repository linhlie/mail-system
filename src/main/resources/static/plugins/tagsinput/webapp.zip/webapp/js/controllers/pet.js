'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:PetCtrl
 * @description
 * # PetCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('PetCtrl', ['$location', '$rootScope', '$http', '$scope', 'currentPet', 'utilService', 
	function($location, $rootScope, $http, $scope, currentPet, utilService) {
	$rootScope.title = 'ペット情報追加/更新';
	$rootScope.page = 'pet';
	var _this = this;
	_this.petList;
	_this.pet = $rootScope.currentPet;
  _this.tmpPetImage = _this.pet.favoritePhoto;
	_this.currentYear = (new Date()).getFullYear();
	_this.isShowNameAlert = false;
	_this.isShowRaceAlert = false;
	_this.isShowGenderAlert = false;
	_this.messages = [];
	_this.hasErrors = true;
	_this.loading = false;
	_this.submitPet = function() {
		//validation check
		_this.messages = [];
		if(_this.pet.name.length === 0) {
			_this.messages.push('ペットの名前を入力してください。');
		//} else if(_this.pet.name.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&').length > 16 || getByteLength(_this.pet.name.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')) > 48) {
		} else if(_this.pet.name.length > 16 || utilService.getByteLength(_this.pet.name) > 48) {
			_this.messages.push('ペットの名前は16文字以内で入力してください。');
		}
		if(_this.pet.petRace.length === 0) {
			_this.messages.push('種別を選択してください。');
		}
		if(_this.pet.petType.length === 0) {
			_this.messages.push('品種を選択してください。');
		}
		if(_this.pet.gender.length === 0) {
			_this.messages.push('性別を選択してください。');
		}
		if(_this.pet.year.length === 0 || _this.pet.month.length === 0 || _this.pet.day.length === 0) {
			_this.messages.push('生年月日を選択してください。');
		}
		if(_this.messages.length > 0){
			window.scrollTo(0,0);
			return;
		}

		//call api to update
		_this.pet.petValid = 1;
  		if(!_this.isShowNameAlert && !_this.isShowRaceAlert && !_this.isShowGenderAlert) {
  			//_this.pet.name = _this.pet.name.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
  			_this.pet.favoritePhoto = _this.pet.favoritePhoto ? _this.pet.favoritePhoto.replace(/data:image\/.*;base64,/g, '') : null;
  			_this.loading = true;
  			$http.post('api/pets/createOrUpdatePet', _this.pet).then(function (response) {
  				$location.path('/profile');
//  				_this.messages = response.data.messages;
//  				_this.hasErrors = false;
  	        }, function (response) {
//  	        	_this.messages = response.data.messages;
//  				_this.hasErrors = true;
  	        });
  		} else {
  			return;
  		}
	}

  	_this.cansel = function() {
  		$location.path('/profile');
  	}


    // 品種リストを取得する
	$http.get('api/pets/getPetSizes').then(function (response) {
		if (response.data) {
			_this.petList = response.data;
		}
    }, function (response) {
    	// error
    	console.log(JSON.stringify(response));
    });

	_this.range = function(min, max, step){
	  step = step || 1;
	  var input = [];
	  for (var i = max; i >= min; i -= step) {
		  input.push(i);
	  }
	  return input;
	};

  	_this.daysMap = {
    		1: 31,
    		2: 28,
    		3: 31,
    		4: 30,
    		5: 31,
    		6: 30,
    		7: 31,
    		8: 31,
    		9: 30,
    		10: 31,
    		11: 30,
    		12: 31
    	};

    	_this.isLeapYear = function(year) {
    		return year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    	}

    	_this.days = [];
    	_this.calculateDays = function() {
    		if (_this.pet) {
	    		if (_this.pet.month && _this.pet.year) {
	        		var month = _this.pet.month;
	        		var year = _this.pet.year;
	    			var numDays = 30;
	        		if (_this.isLeapYear(year) && month === 2) {
	        			numDays = 29;
	        		} else {
	        			numDays = _this.daysMap[month];
	        		}
	        		_this.days = [];
	        		for (var i = 1; i <= numDays; i++) {
	        			_this.days.push(i);
	        		}
	    		}
    		}
    	}
    	_this.calculateDays();

//    	var getByteLength = function(str) {
//    		return encodeURIComponent(str).replace(/%../g,"x").length;
//    	}

    	this.close = function (idx, arr) { arr.splice(idx, 1) };

      _this.registerImage = function () { $location.path('/register_image') };

      $(function () {
        if ($rootScope.browserBackCountermeasure) {
          _this.tmpPetImage = $rootScope.favoritePhoto;
          _this.pet.favoritePhoto = $rootScope.favoritePhoto;
          $rootScope.browserBackCountermeasure = null;
          $rootScope.favoritePhoto = null;
        } else {
          $rootScope.browserBackCountermeasure = null;
          $rootScope.favoritePhoto = null;
        }
      });
}]);
