'use strict';

angular.module('kyorituChatUiApp')
.controller('registerImageController',['$rootScope', '$scope', '$http', '$location', 'currentPet', function ($rootScope, $scope, $http, $location, currentPet) {
  var _this = this;
  $rootScope.page = 'register_image';
  _this.pet = $rootScope.currentPet;
  _this.tmpImageURI = _this.pet.favoritePhoto;
  $rootScope.browserBackCountermeasure = true;
  $rootScope.favoritePhoto = _this.pet.favoritePhoto;
  _this.cnvsFlg = false;
  _this.messages = [];
  _this.hasErrors = false;
  _this.deleteFlg = false;

  $('input[type=file]').change(function () {
    _this.hasErrors = false;
    _this.messages = [];
    var file = null; // 選択されるファイル
    // ファイルを取得
    file = $(this).prop('files')[0];
    // 選択されたファイルが画像かどうか判定
    if (file.type != 'image/jpeg' && file.type != 'image/png') {
      // 画像でない場合は終了
      var file = null;
      _this.hasErrors = true;
      _this.messages = ['画像ファイルを指定してください。'];
      $scope.$apply();
      window.scrollTo(0,0);
      return;
    }
    if (file.size > 20971520) {
      var file = null;
      _this.hasErrors = true;
      _this.messages = ['サイズが20メガバイト未満のファイルを選択してください。'];
      $scope.$apply();
      window.scrollTo(0,0);
      return;
    }
    _this.cnvsFlg = true;
    _this.deleteFlg = false;
    $scope.$apply();
    var reader = new FileReader();
    reader.onload = function (e) {
      if (e.target.result.indexOf('data:image/') >= 0) {
        imageRendering(e.target.result);
      } else {
        var file = null;
        _this.hasErrors = true;
        _this.messages = ['画像ファイルを指定してください。'];
        _this.clearImage();
        window.scrollTo(0,0);
        $scope.$apply();
        return;
      }
    }
    reader.readAsDataURL(file);
  });

  _this.clearImage = function () {
    if (_this.cnvsFlg && _this.pet.favoritePhoto) {
      var canvas = document.getElementById('cnvs');
      var ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      _this.cnvsFlg = false;
      _this.pet.favoritePhoto = null;
    } else if (!_this.deleteFlg) {
      _this.cnvsFlg = false;
      _this.deleteFlg = true;
      var img = new Image();
      img.src = '../images/take_photo.svg';
      img.onload = function() {
        var c = document.getElementById('photo_icon');
        var ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0, 150, 150);
        _this.pet.favoritePhoto = c.toDataURL('image/jpeg');
      }
    }
  }

  _this.choosePhoto = function () {
    $rootScope.browserBackCountermeasure = false;
    $location.path('/pet');
  }

  _this.cancel = function () {
    $rootScope.browserBackCountermeasure = false;
    _this.pet.favoritePhoto = _this.tmpImageURI;
    $location.path('/pet');
  }

  var getSize = function (image, maxWidth) {
    var naturalWidth = image.naturalWidth;
    var naturalHeight = image.naturalHeight;
    var width = 0;
    var height = 0;
    if (naturalWidth > naturalHeight) {
      width = maxWidth;
      height = parseInt(naturalHeight*maxWidth/naturalWidth);
    } else {
      height = maxWidth;
      width = parseInt(naturalWidth*maxWidth/naturalHeight);
    }
    return {width, height};
  }

  var byteStringToOrientation = function (img) {
    var head = 0;
    var orientation;
    while (1) {
      if (img.charCodeAt(head) == 255 & img.charCodeAt(head + 1) == 218) {
        break;
      }
      if (img.charCodeAt(head) == 255 & img.charCodeAt(head + 1) == 216) {
        head += 2;
      } else {
        var length = img.charCodeAt(head + 2) * 256 + img.charCodeAt(head + 3);
        var endPoint = head + length + 2;
        if (img.charCodeAt(head) == 255 & img.charCodeAt(head + 1) == 225) {
          var segment = img.slice(head, endPoint);
          var bigEndian = segment.charCodeAt(10) == 77;
          var count;
          if (bigEndian) {
            count = segment.charCodeAt(18) * 256 + segment.charCodeAt(19);
          } else {
            count = segment.charCodeAt(18) + segment.charCodeAt(19) * 256;
          }
          for (var i = 0; i < count; i++) {
            var field = segment.slice(20 + 12 * i, 32 + 12 * i);
            if ((bigEndian && field.charCodeAt(1) == 18) || (!bigEndian && field.charCodeAt(0) == 18)) {
              orientation = bigEndian ? field.charCodeAt(9) : field.charCodeAt(8);
            }
          }
          break;
        }
        head = endPoint;
      }
      if (head > img.length){
        break;
      }
    }
    return orientation;
  }

  var getOrientation = function (imgDataURL) {
    var byteString = atob(imgDataURL.split(',')[1]);
    var orientaion = byteStringToOrientation(byteString);
    return orientaion;
  }

  var imageRendering = function (src) {
    var img = new Image();
    img.onload = function () {
      var orientate = getOrientation(img.src);
      var preCnvs = document.createElement('canvas');
      var preCtx = preCnvs.getContext('2d');
      preCnvs.width = img.width;
      preCnvs.height = img.height;
      if (orientate == 3) { // 横位置（上下逆）
        preCnvs.width = img.width;
        preCnvs.height = img.height;
        preCtx.translate(preCnvs.width/2, preCnvs.height/2);
        preCtx.rotate(Math.PI);
        preCtx.translate(-img.width/2, -img.height/2);
      } else if (orientate == 6) { // 縦位置
        preCnvs.width = img.height;
        preCnvs.height = img.width;
        preCtx.translate(preCnvs.width/2, preCnvs.height/2);
        preCtx.rotate(Math.PI / 2);
        preCtx.translate(-img.width/2, -img.height/2);
      }
      preCtx.drawImage(img, 0, 0);
      var newImage = new Image();
      // 画面プレビュー用画像作成と表示を行う
      newImage.onload = function() {
        var cnvs = document.getElementById('cnvs');
        var ctx = cnvs.getContext('2d');
        var container = document.getElementById('canvas-container');
        var width = container.clientWidth;
        var size = getSize(newImage, width);
        var w = size.width;
        var h = size.height;
        cnvs.setAttribute('width', w);
        cnvs.setAttribute('height', h);
        ctx.drawImage(newImage, 0, 0, w, h);
      }
      _this.pet.favoritePhoto = preCnvs.toDataURL('image/jpeg');
      newImage.src = _this.pet.favoritePhoto;
    }
    img.src = src;
  }

  $(function () {
    if (_this.pet.favoritePhoto) {
      _this.cnvsFlg = true;
      $scope.$apply();
      imageRendering(_this.pet.favoritePhoto);
    }
  });

  this.close = function (idx, arr) { arr.splice(idx, 1) };

}]);
