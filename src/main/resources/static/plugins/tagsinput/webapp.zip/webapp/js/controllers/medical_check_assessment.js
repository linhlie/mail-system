'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:MedicalCheckAssessmentCtrl
 * @description
 * # MedicalCheckAssessmentCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('MedicalCheckAssessmentCtrl',  ['$rootScope', '$scope', '$http', '$location', 'currentUser', '$routeParams',  function ($rootScope, $scope, $http, $location, currentUser, $routeParams) {
	$rootScope.title = '受診予備チェック結果画面';
	$rootScope.page = 'medical_check_assessment';
	var _this = this;
	_this.interviewId = $routeParams.interview_id
	_this.message = '受診予備チェック結果を取得しています...';
	_this.isModalOpen = false;
	
	//fullpage.jsを破棄してスクロールを有効化
	if($rootScope.isFullpageCalled) {
		$.fn.fullpage.destroy('all');
	}
	
	var urgencyMessageMap = {
		'LOW': '今聞いた内容から判断すると緊急の問題は無さそうですが、念のため近いうちに病院で診てもらった方が良いですよ。<br><br>' +  
				'このチェックは、獣医師監修のもと作成されており、実際に動物病院で診断に使用されている項目をまとめているため、' +
				'リンク先の結果を医師に提示することを推奨しています。',
		'MID': '今聞いた内容から判断すると、できれば今日か明日、病院に行ったほうが良いですよ。<br><br>' +
			'このチェックは、獣医師監修のもと作成されており、実際に動物病院で診断に使用されている項目をまとめているため、' +
			'リンク先の結果を医師に提示することを推奨しています。',
		'HIGH': '今聞いた内容から判断すると、すぐに病院に行ったほうが良いですよ。<br><br>' +
			'このチェックは、獣医師監修のもと作成されており、実際に動物病院で診断に使用されている項目をまとめているため、' +
			'リンク先の結果を医師に提示することを推奨しています。',
	};
		
	//ユーザの受診予備チェック結果を取得し、該当アセスメント結果を表示
	$http.post('api/interviews/getUrgency', {"interviewId" : _this.interviewId}).then(
			function (response) {
				var urgency = response.data;
				var message = urgencyMessageMap[urgency];
				if (!message) {
					message = 'すみません、結果が取得できなかったので、しばらく時間を置いてもう一度試してみてください。'
				}
				_this.message = message;
			},
			function (response) {
				_this.message = '受診予備チェック結果の取得に失敗しました。';
				console.log(JSON.stringify(response));
			}
		);
}]);