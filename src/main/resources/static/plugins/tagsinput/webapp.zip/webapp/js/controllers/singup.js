'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:LogsCtrl
 * @description
 * # SignupCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('SignupCtrl', ['$rootScope', '$scope', '$http', 'utilService', function ($rootScope, $scope, $http, utilService) {
	$rootScope.title = '新規登録';
	$rootScope.page = 'signup';
	
	var _this = this;
	$rootScope.currentUser = null; // $rootScopeで保持しているユーザー情報をクリア
	this.user = this.user || {};
	this.messages = [];
	this.hasErrors = false;
    $scope.waiting = false;

    if (window.messages) { // main.jspにメッセージがセットされている場合
        this.messages = window.messages; // 詰め替えて
        window.messages = null; // main.jspのメッセージを削除
    }
    
    this.signup = function () {
    	_this.hasErrors = false;
    	_this.messages = [];
        if (this.signupForm.$invalid) {
            return;
        }
        //if(_this.user.name.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&').length > 33 || getByteLength(_this.user.name.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')) > 100) {
        if(_this.user.name.length > 33 || utilService.getByteLength(_this.user.name) > 100) {
			_this.messages.push('ユーザ名は33文字以内で入力してください。');
		}
		if(_this.messages.length > 0){
			window.scrollTo(0,0);
			_this.hasErrors = true;
			return;
		}
        $scope.waiting = true;

        $http.post('api/auth/createUser', this.user).then(
            (function (response) {
            	$scope.waiting = false;
            	if (!response.data.success) {
            		_this.hasErrors = true;
            		$scope.waiting = false;
            	}
                this.messages.push('');
                setTimeout(function () {
                	$('#message_'+ (_this.messages.length - 1)).html(response.data.messages);
                }, 0);
            }).bind(this),
            (function (response) {
            	_this.hasErrors = true;
            	$scope.waiting = false;
                this.messages = response.data.messages;
            }).bind(this)
        );
    };
    
    this.close = function (idx, arr) { arr.splice(idx, 1) }
    
    this.openEmailError = function () {
    	if(this.signupForm.email.$error.email){
    	$scope.emailError = true;
    	}
    }
    
    this.closeEmailError = function () {
    	$scope.emailError = false;
    }
    
//	var getByteLength = function(str) {
//		return encodeURIComponent(str).replace(/%../g,"x").length;
//	}
}]);
