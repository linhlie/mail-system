'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:DetailCtrl
 * @description
 * # ForgotCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('ForgotController', ['$scope', '$rootScope', '$http', '$location', '$routeParams', function ($scope, $rootScope, $http, $location, $routeParams) {
	var _this = this;
	$rootScope.page = 'forgot';
	this.success = false;
	this.messages = [];
	this.hasErrors = false;
	$scope.waiting = false;

	this.update = function () {
		if ($scope.waiting || _this.updateForm.$invalid) {
			return;
		}
		if(this.user.password === this.user.passwordRepeat){
			this.messages = [];
	        var digest = $routeParams.digest;
	        $scope.waiting = true;
	        $http.post('api/auth/updateForgot', { password: this.user.password, digest: digest }).then(
	            (function (response) {
	                if (response.data.success) {
	                    _this.success = true;
	                    _this.hasErrors = false;
	                } else {
	                	$scope.waiting = false;
	                	_this.success = false;
	                	_this.hasErrors = true;
	                }
	                _this.messages = response.data.messages;
	            }).bind(this),
	            (function (response) {
	            	$scope.waiting = false;
	            	_this.hasErrors = true;
	                _this.messages = response.data.messages;
	            }).bind(this)
	        );
		} else {
			_this.success = false;
			_this.hasErrors = true;
			_this.messages = ["パスワードが一致していません。"]
		}
    };

    this.close = function (idx, arr) { arr.splice(idx, 1) };
}]);
