'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:FrontCtrl
 * @description
 * # FrontCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.config(['slickCarouselConfig', function (slickCarouselConfig) {
        slickCarouselConfig.dots = true;
        slickCarouselConfig.autoplay = false;
    }])
.controller('FrontCtrl', ['$rootScope','$scope', '$http', '$routeParams', '$location', function ($rootScope, $scope, $http, $routeParams, $location) {
	$rootScope.title = 'ホームズについて';
	$rootScope.page = 'front';
	$scope.open1 = true;
	$scope.open2 = true;
	$scope.open3 = true;
	
	var _this = this;
	_this.message;
	_this.response;
	_this.isModalOpen = false;
    _this.awesomeThings = [
        'HTML5 Boilerplate',
        'AngularJS',
        'Karma'
      ];

    if (window.message) { // main.jspにメッセージがセットされている場合
        this.message = window.message[0]; // 詰め替えて
        window.message = null; // main.jspのメッセージを削除
        _this.isModalOpen = true;
    }

  	if($routeParams.dg !== undefined){
  		_this.isModalOpen = true;
  		// パスワード・メールアドレス変更メールから変更したときだけ、
  		// update APIが走って、モーダルが表示される
  		var digest = $routeParams.dg;
  		$http.post('api/auth/updateEmail', { digest: digest })
  	    .then(
  	        (function (response) {
  	        	_this.response = response;
  	        	_this.message = response.data.messages[0]; // 同じダイジェストで二回アクセスされて二度目は更新が行われなくても画面上はsuccessとする
  	        }).bind(this),
  	        (function (response) {
  	        	_this.response = response;
  	            this.message = response.data.messages;
  	        }).bind(this)
  	    );
  	}
    this.closeModal = function () {
    	_this.isModalOpen = false;
    	if (_this.response.data.success) {
    		$location.path('/login');
    	} else {
    		$location.path('#');
    	}
    };
    $scope.number = [
        {label: 'icon_step1.svg', txt: "無料アカウントを<br>今すぐ登録"}, 
        {label: 'icon_step2.svg', txt: "ペット（犬か猫）を<br>登録"}, 
        {label: 'icon_step3.svg', txt: "AI Dr.ホームズと<br>チャット開始！"}
      ];
      $scope.numberLoaded = true;
      $scope.numberUpdate = function(){
          $scope.numberLoaded = true; // enable slick
      };
    
      $scope.slickConfig = {
        autoplay: true,
        method: {},
        event: {
            setPosition: function(event, slick) {
            	// 最後に行きましたら、先頭へ飛ばす
            	var slideCount = slick.slideCount;
            	if (slideCount > 1) {
            		if (slick.currentSlide + 1 >= slideCount) {
            			slick.currentSlide = -1;
            			slick.direction = 1;
            		}
            	}
            }
        },
        dots: true,
        infinite: false,
        centerMode: true,
        speed: 300,
        slidesToShow: 1,
        variableWidth: true,
        arrows: false
      };
}]);