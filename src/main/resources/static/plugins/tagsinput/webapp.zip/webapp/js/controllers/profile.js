'use strict';

/**
* @ngdoc function
* @name kyorituChatUiApp.controller:ProfileCtrl
* @description
* # ProfileCtrl
* Controller of the kyorituChatUiApp
*/
angular.module('kyorituChatUiApp')
.controller('ProfileCtrl',['$rootScope', '$scope', '$http', '$location', 'currentUser', 'utilService',
function ($rootScope, $scope, $http, $location, currentUser, utilService) {
	$rootScope.title = 'プロフィール編集';
	$rootScope.page = 'profile';
	var _this = this;
	this.user = JSON.parse(JSON.stringify(currentUser));
	if(this.user.postalCode) {
		this.user.postalCode = this.user.postalCode.trim();
	}
	this.pets = [];
	$rootScope.currentPet = null;
	this.messages = [];
	this.hasErrors = false;
	this.postalCodeRegex = /^\d{3}-\d{4}$|^\d{7}$/;
	$scope.waiting = false;
	_this.loading = true;

	$rootScope.$on("$routeChangeSuccess", function (event, currentRoute, previousRoute) {
		window.scrollTo(0, 0);
	});

	$http.post('api/pets/getUserPets', currentUser)
	.then(function (response) {
		if (response.data && response.data.length > 0) {
			_this.pets = response.data;
		}
		_this.loading = false;
	}, function (response) {
		console.log(JSON.stringify(response));
		_this.loading = false;
	});

	this.submitUser = function() {
		$scope.waiting = true;
		_this.hasErrors = false;
		_this.messages = [];
		if (this.userForm.$invalid) {
			$scope.waiting = false;
			return;
		}
		//_this.user.name = _this.user.name.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
		if (utilService.getByteLength(_this.user.name) > 96 || _this.user.name.length > 32) {
			window.scrollTo(0, 0);
			$scope.waiting = false;
			_this.messages.push("ユーザ名は1文字以上32文字以内で入力してください。");
			_this.hasErrors = true;
			return;
		}

		$http.post('api/auth/updateUserInfo', _this.user).then(function (response) {
			$scope.waiting = false;
			_this.messages = response.data.messages;
			_this.hasErrors = false;
			// ユーザー情報更新しただけでは、緯度経度情報がcurrentUserに入らず、chat画面に遷移できないので、
			// ここで一度、getCurrentUserしてサーバーに問い合わせる。
			$http.get('api/auth/getCurrentUser').then(
				function (response) {
					window.scrollTo(0, 0);
					$rootScope.currentUser = response.data;
					_this.messages.push('');
					setTimeout(function () {
						var str = '更新しました。<a href="#!/chat">ここ</a>からAI Dr.ホームズへの相談を始めましょう。';
						if (_this.pets.length == 0) {
							str = 'ペット情報を登録してAI Dr.ホームズへの相談を始めましょう';
						}
						$('#message_'+ (_this.messages.length - 1)).html(str);
					}, 0);
				},
				function (response) {
					//TODO : error handling
					return;
				}
			);
		}, function (response) {
			// error
			$scope.waiting = false;
			_this.messages = response.data.messages;
			_this.hasErrors = true;
		});
	}

	this.selectPet = function(index) {
		var currentPet = _this.pets[index];
		$http.post('api/pets/selectPet', currentPet).then(function (response) {
			$rootScope.currentPet = response.data;
			$location.path('/pet');
		}, function (response) {
			console.log(JSON.stringify(response));
		});
	}

	this.addPet = function() {
		$rootScope.currentPet = {
			name: '',
			day : '',
			gender : '',
			month : '',
			petId : '',
			petRace : '',
			petType : '',
			updateTime : '',
			userId : currentUser.userId,
			year : '',
			petValid: ''
		}
		$location.path('/pet');
	}

//	var getByteLength = function(str) {
//		return encodeURIComponent(str).replace(/%../g,"x").length;
//	}

	this.close = function (idx, arr) { arr.splice(idx, 1) };
}]);
