'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:FrontCtrl
 * @description
 * # FrontCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('homeController', ['$rootScope','$scope', '$http', '$routeParams', '$location', function ($rootScope, $scope, $http, $routeParams, $location) {
	$rootScope.title = 'ホーム';
	$rootScope.page = 'home';
	var _this = this;
	_this.message;
	_this.response;
	_this.isModalOpen = false;

    if (window.message) { // main.jspにメッセージがセットされている場合
        this.message = window.message[0]; // 詰め替えて
        window.message = null; // main.jspのメッセージを削除
        _this.isModalOpen = true;
    }

  	if($routeParams.dg !== undefined){
  		_this.isModalOpen = true;
  		// パスワード・メールアドレス変更メールから変更したときだけ、
  		// update APIが走って、モーダルが表示される
  		var digest = $routeParams.dg;
  		$http.post('api/auth/updateEmail', { digest: digest })
  	    .then(
  	        (function (response) {
  	        	_this.response = response;
  	        	_this.message = response.data.messages[0]; // 同じダイジェストで二回アクセスされて二度目は更新が行われなくても画面上はsuccessとする
  	        }).bind(this),
  	        (function (response) {
  	        	_this.response = response;
  	            this.message = response.data.messages;
  	        }).bind(this)
  	    );
  	}
    this.closeModal = function () {
    	_this.isModalOpen = false;
    	if (_this.response.data.success) {
    		$location.path('/login');
    	} else {
    		$location.path('#');
    	}
    };
}]);