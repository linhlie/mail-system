/**
 * @ngdoc overview
 * @name kyorituChatUiApp
 * @description
 * # 認証周りのメソッド（ログアウト処理、currentUserをrootScopeにセットする処理等）をまとめたモジュール
 */

'use strict';
angular.module('kyorituChatUiApp')
    .factory('authService', ['$rootScope', '$http', '$location', function($rootScope, $http, $location) {
    	var service = {
    		logout: function(callbackError) {
    			$http.get('api/auth/logout').then(
                    function (response) {
                    	$rootScope.currentUser = null;
                        $location.path('/front');
                    },
                    function (response) {
                    	if (callbackError) {
                    		callbackError(response);
                    	} else {
                    		console.log(JSON.stringify(response));
                    	}
                    }
                );
    		},
    		currentUser: function(callbackError) {
    			if (!$rootScope.currentUser) { // ユーザー情報を$rootScopeで保持していない場合
    				$http.get('api/auth/getCurrentUser').then( // サーバーにユーザー情報を問い合わせ
    					function (response) {
    						$rootScope.currentUser = response.data; //  ユーザー情報を$rootScopeにセット
    					},
    					function (response) {
    						if (callbackError) {
    							callbackError(response);
    						} else {
    							console.log(JSON.stringify(response));
    						}
    					}
    				);
    			}
    		}
    	};
    	return service;
	}]);