'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:LogsCtrl
 * @description
 * # ForgotPasswordCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('ForgotPasswordCtrl', ['$rootScope', '$scope', '$http', function ($rootScope, $scope, $http) {
	$rootScope.title = 'パスワード変更';
	$rootScope.page = 'forgot_password';
	var _this = this;
	$rootScope.currentUser = null; // $rootScopeで保持しているユーザー情報をクリア
	this.user = this.user || {};
	this.messages = [];
	this.hasErrors = false;
    $scope.waiting = false;

    if (window.messages) { // main.jspにメッセージがセットされている場合
        this.messages = window.messages; // 詰め替えて
        window.messages = null; // main.jspのメッセージを削除
    }

    this.forgotPassword = function () {
    	if ($scope.waiting || _this.forgotForm.$invalid) {
    		return;
    	};
    	_this.hasErrors = false;
    	_this.messages = [];
    	$scope.waiting = true;

        $http.post('api/auth/forgotPassword', this.user).then(
            (function (response) {
            	var data = response.data;
            	if (!data.success) {
            		_this.hasErrors = true;
            		$scope.waiting = false;
            	}
                this.messages = data.messages;
            }).bind(this),
            (function (response) {
            	_this.hasErrors = true;
            	$scope.waiting = false;
                this.messages = response.data.messages;
            }).bind(this)
        );
    };

    this.close = function (idx, arr) { arr.splice(idx, 1) };
    
    this.openEmailError = function () {
    	if(this.forgotForm.email.$error.email){
    	$scope.emailError = true;
    	}
    }
    
    this.closeEmailError = function () {
    	$scope.emailError = false;
    }
}]);
