/**
 * TODO:ディレクティブの説明を記載
 */
'use strict';
angular.module('kyorituChatUiApp')
	.directive('ngEnter', function () { // Enter押下時に処理を呼び出すdirective
        return function (scope, element, attrs) {
            element.bind('keydown', function (e) {
                if (e.which === 13) {
                    e.preventDefault();
                    scope.$apply(function () {
                        scope.$eval(attrs.ngEnter);
                    });
                }
            });
        };
    }) 