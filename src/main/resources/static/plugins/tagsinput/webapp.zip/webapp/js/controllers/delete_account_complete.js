'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
  .controller('deleteAccountCompleteController', ['$rootScope', '$scope','$http', '$location', function ($rootScope, $scope, $http, $location) {
	$rootScope.title = '退会完了';
	$rootScope.page = 'delete_account_complete';
}]);