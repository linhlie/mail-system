'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:privacyPolicyController
 * @description
 * # privacyPolicyController
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('privacyPolicyController',['$rootScope', '$scope', '$window', function ($rootScope, $scope, $window) {
	$rootScope.title = 'プライバシーポリシー';
	$rootScope.page = 'privacy_policy';
	$window.scrollTo(0, 0);
}]);
