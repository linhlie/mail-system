/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:ChatCtrl
 * @description
 * # HealthCheckSurveyCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
  .controller('HealthCheckSurveyCtrl', ['$rootScope', '$scope', '$http', '$location', 'currentUser', '$routeParams',  function ($rootScope, $scope, $http, $location, currentUser, $routeParams) {
  $rootScope.title = '健康チェック';
  $rootScope.page = 'health_check_survey';
	let submitAnswers ={};
	if(!$rootScope.selectedPetIdForCheck) {
		console.log('ペットを選択してください');
		$location.path('/logs/');
	}
	$scope.loading = true;
	submitAnswers.petId = $rootScope.selectedPetIdForCheck;
	$rootScope.selectedPetIdForCheck = '';
	this.answers = [];
	this.SURVEY_TEXT_MAX = 125;
	this.buttonClicked = false;
	//steady == '普通', up == '増えた', down == '減った'
	this.answers['check1'] = 'steady';

	//steady == '普通', up == '増えた', down == '減った'
	this.answers['check2'] = 'steady';

	//Yes == 'ある', No == 'ない'
	this.answers['check3'] = 'No';

	//steady == '普通', up == '増えた', down == '減った'
	this.answers['check4'] = 'steady';

	//Yes == 'ある', No == 'ない'
	this.answers['check5'] = 'No';

	//Yes == 'ある', No == 'ない'
	this.answers['check6'] = 'No';

	//Yes == 'ある', No == 'ない'
	this.answers['check7'] = 'No';

	//Yes == 'ある', No == 'ない'
	this.answers['check8'] = 'No';

	//steady == '普通', up == '増えた', down == '減った'
	this.answers['check9'] = 'steady';

	//No == 'ない', muddy == 'にごりあり', red == '赤色あり'
	this.answers['check10'] = 'No';

	//Yes == 'ある', No == 'ない'
	this.answers['check11'] = 'No';

	//Yes == 'ある', No == 'ない'
	this.answers['check12'] = 'No';

	//steady == '普通', up == '増えた', down == '減った'
	this.answers['check13'] = 'steady';

	//steady == '普通', up == '増えた', down == '減った'
	this.answers['check14'] = 'steady';

	//steady == '普通', up == '良くなった', down == '悪くなった'
	this.answers['check15'] = 'steady';

	//Yes == 'ある', No == 'ない'
	this.answers['check16'] = 'No';

	//down == '低下したよう', No == 'ない'
	this.answers['check17'] = 'No';

	//Yes == 'ある', No == 'ない'
	this.answers['check18'] = 'No';
	this.answers['check19'] = '';
	this.answers['check20'] = '';
	this.answers['check21'] = '';
	this.answers['check22'] = '';
	this.answers['check23'] = '';
	this.answers['check24'] = '';
	this.answers['check25'] = '';
	
	this.backTologs = function() {
		$location.path('/logs/');
	}

	$(document).ready(function(){
		if($rootScope.isFullpageCalled) {
			$.fn.fullpage.destroy('all');
		}
			$('#fullpage').fullpage({
				//スワイプによる質問の遷移を禁止
				touchSensitivity: 999999999,
				afterRender: function(){
					$scope.$apply(function () {
						$scope.loading = false;
					});
				}
			});
			$rootScope.isFullpageCalled = true;
		});
	
	//次へがクリックされたら、fullPage.jsの横スクロールを発火
	$('.next').on('click',function(){
		$(".fp-next").click();
	});

	//戻るがクリックされたら、fullPage.jsの横スクロールを発火
	$('.prev').on('click',function(){
		$(".fp-prev").click();
	});

	this.submitSurvey = function() {
		//APIに合わせたjson構造に変更
		submitAnswers.userId = currentUser.userId;
		submitAnswers.check1 = this.answers['check1'];
		submitAnswers.check2 = this.answers['check2'];
		submitAnswers.check3 = this.answers['check3'];
		submitAnswers.check4 = this.answers['check4'];
		submitAnswers.check5 = this.answers['check5'];
		submitAnswers.check6 = this.answers['check6'];
		submitAnswers.check7 = this.answers['check7'];
		submitAnswers.check8 = this.answers['check8'];
		submitAnswers.check9 = this.answers['check9'];
		submitAnswers.check10 = this.answers['check10'];
		submitAnswers.check11 = this.answers['check11'];
		submitAnswers.check12 = this.answers['check12'];
		submitAnswers.check13 = this.answers['check13'];
		submitAnswers.check14 = this.answers['check14'];
		submitAnswers.check15 = this.answers['check15'];
		submitAnswers.check16 = this.answers['check16'];
		submitAnswers.check17 = this.answers['check17'];
		submitAnswers.check18 = this.answers['check18'];
		submitAnswers.phMed = this.answers['check19'];
		submitAnswers.phSurg = this.answers['check20'];
		submitAnswers.phTra = this.answers['check21'];
		submitAnswers.pv = this.answers['check22'];
		submitAnswers.env = this.answers['check23'];
		submitAnswers.getRoute = this.answers['check24'];
		submitAnswers.diet = this.answers['check25'];
		if(!this.buttonClicked) {
			//「送信」ボタンのクリックを１回に制御
			this.buttonClicked = true;
			$http.post('api/interviews/createHealthCheck', submitAnswers).then(function (response) {
				if(!response.data.success) {
					console.log('health check insert error');
				} else {
					$http.get('api/interviews/getUserHealthChecks').then(function (response) {
						$location.path('/health_check_assessment/' + response.data[0].healthCheckId);
					});
				}
		    });
		}
	}
}]);
