'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:UserEmailChangeController
 * @description
 * # PetCtrl2
 * Controller of the UserEmailChangeController
 */
angular.module('kyorituChatUiApp')
.controller('UserPasswordChangeController', ['$rootScope', '$scope', '$http', '$location', 'currentUser', function ($rootScope, $scope, $http, $location, currentUser) {
	$rootScope.title = 'パスワード変更';
	$rootScope.page = 'user_password_change';
	console.log($scope);
	var _this = this;
	this.currentUser = currentUser;
	this.messages = [];
	this.hasErrors = false;

	this.password = '11111111';
	this.newPassword = '';
	this.newPasswordRepeat = '';
	this.isModalOpen = false;

	this.updatePassword = function() {
		_this.hasErrors = false;
		_this.messages = [];
		if (_this.newPassword !== _this.newPasswordRepeat) {
			_this.messages = ['パスワードが一致しません。'];
			_this.hasErrors = true;
			return;
		}
		_this.currentUser.password = _this.password;
		_this.currentUser.tempPassword = _this.newPassword;
		$http.post('api/auth/updatePassword', _this.currentUser).then(function (response) {
			_this.messages = response.data.messages;
			if(response.data.success) {
				_this.hasErrors = false;
				_this.isModalOpen = true;
				$scope.message = 'パスワード変更に成功しました。';
			} else {
				_this.messages = response.data.messages;
				_this.hasErrors = true;
			}
			_this.newPassword = '';
			_this.newPasswordRepeat = '';
        }, function (response) {
        	// error
        	_this.messages = response.data.messages;
        	_this.hasErrors = true;
        });
	}

    this.closeModal = function () {
    	_this.isModalOpen = false;
    	_this.messages = [];
    	$location.path('/profile');
    };
    this.back = function () {$location.path('/user_settings');};
    this.close = function (idx, arr) { arr.splice(idx, 1) }
}]);
