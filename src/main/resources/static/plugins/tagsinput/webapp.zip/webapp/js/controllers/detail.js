'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:DetailCtrl
 * @description
 * # DetailCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
  .controller('DetailCtrl', ['$rootScope', '$scope', '$http', '$location', 'currentUser', '$routeParams',  function ($rootScope, $scope, $http, $location, currentUser, $routeParams) {
	$rootScope.title = '受診予備チェック';
	$rootScope.page = 'detail';
	var _this = this;
	_this.interviewId = $routeParams.interview_id
	_this.petLog = [];
	_this.pets=[];
	_this.pet=[];

	/**
	 * yyyy-mm-dd 形式の誕生日から年齢を計算
	 */

/*	var calculateAge = function(birthday) {
		var  birth = birthday.split('-'); // birth[0]: year, birth[1]: month, birth[2]: day
		var _birth = parseInt("" + birth[0] + affixZero(birth[1]) + affixZero(birth[2]));// 文字列型に明示変換後にparseInt
		var  today = new Date();
		var _today = parseInt("" + today.getFullYear() + affixZero(today.getMonth() + 1) + affixZero(today.getDate()));// 文字列型に明示変換後にparseInt
		return parseInt((_today - _birth) / 10000);
	}
*/
	/**
	 * 1, 2 など 1桁の数値を 01, 02 などの文字列に変換（2桁以上の数字は単純に文字列型に変換）
	 */
	var affixZero = function(int) {
		if (int < 10) int = "0" + int;
		return "" + int;
	}


	//ユーザの問診票を取得
	$http.get('api/interviews/getInterview', {
		params: {
			interview_id: _this.interviewId
		},
		headers : {'Accept' : 'application/json'}
		}).then(
			function (response) {
				_this.petLog = response.data;
				getUserPets();
			},
			function (response) {
				console.log(JSON.stringify(response));
			}
		);

	var getUserPets = function () {
		$http.post('api/pets/getUserPets', currentUser).then(function (response) {
			if (response.data && response.data.length > 0) {
				_this.pets = response.data;
				for(var i=0,l=_this.pets.length;i<l;i++){
					if(_this.pets[i]["petId"] == _this.petLog["petId"]){
						_this.pet=_this.pets[i];
						_this.pet.birthday = _this.pet["year"] + "-" + _this.pet["month"] + "-" + _this.pet["day"];
					}
				}
			}
	    }, function (response) {
	    	console.log(JSON.stringify(response));
	    });
	}

}]);
