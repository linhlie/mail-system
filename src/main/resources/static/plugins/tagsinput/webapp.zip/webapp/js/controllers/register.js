'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:DetailCtrl
 * @description
 * # RegisterCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('RegisterCtrl', ['$scope', '$http', '$location', '$routeParams', '$rootScope', function ($scope, $http, $location, $routeParams, $rootScope) {
	$rootScope.page = 'register';
	this.init = false;
	this.success = false;
	this.messages = [];
    var digest = $routeParams.digest;
    $http.post('api/auth/registerUser', { digest: digest }).then(
        (function (response) {
        	if (response.data) {
        		this.success = true; // 同じダイジェストで二回アクセスされて二度目は更新が行われなくても画面上はsuccessとする
        	} else {
        		this.success = false;
        	}
        	this.init = true;
        }).bind(this),
        (function (response) {
            this.messages = response.data.messages;
        }).bind(this)
    );
    
    this.close = function (idx, arr) { arr.splice(idx, 1) };
}]);
