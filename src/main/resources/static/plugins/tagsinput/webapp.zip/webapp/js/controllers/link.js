'use strict';

/**
 * @ngdoc function
 * @name kyorituChatUiApp.controller:LinkCtrl
 * @description
 * # LinkCtrl
 * Controller of the kyorituChatUiApp
 */
angular.module('kyorituChatUiApp')
.controller('linkController',['$rootScope', '$scope', '$location', function ($rootScope, $scope, $location) {
	$rootScope.title = 'AI Drホームズ ご紹介用バナー';
	$rootScope.page = 'link';
	window.scrollTo(0, 0);

	// レスポンシブ対応のため、800pxを境界にメディアクエリリストの設定
	var mql = window.matchMedia('(max-width: 799px)');

	// matches stateに応じて要素のサイズ、ズームを設定する関数
	var handleMediaQueryListMatchesState = function (matches) {
		if (matches) {
			$('.dh--container').css('width', '100vw');
			// 拡大率(%)の計算 ((画面サイズ - 左右のマージン30px) ÷ 通常時の画面幅720px × 100)
			var rate = Math.floor(($(window).width() - 30) / 720 * 100);
			// 拡大率を適用する箇所にセット
			$('.index01').css('zoom',  rate + '%');
			$('.index02').css('zoom',  rate + '%');
			$('.index04').css('zoom',  rate + '%');
		} else {
			// 画面幅をセットし、拡大率は100%にする
			$('.dh--container').css('width', '720px');
			$('.index01').css('zoom', '100%');
			$('.index02').css('zoom', '100%');
			$('.index04').css('zoom', '100%');
		}
	}

	// イベントリスナの設定
//	mql.addListener(function(e) {
//		// matches stateの変化を検知させる
//		handleMediaQueryListMatchesState(e.matches);
//	});
	var timer = false;
	$(window).resize(function () {
		if (timer !== false) {
			clearTimeout(timer);
		}
		timer = setTimeout(function () {
			handleMediaQueryListMatchesState(mql.matches);
		}, 200);
	})

	// 初期化
	handleMediaQueryListMatchesState(mql.matches);
}]);
