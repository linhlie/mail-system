/**
 * @ngdoc overview
 * @name kyorituChatUiApp
 * @description
 * # エスケープ処理を行うメソッドを定義するモジュール
 */

'use strict';
angular.module('kyorituChatUiApp')
	.factory('utilService', ['$rootScope', '$http', function($rootScope, $http) {
    	
    	var escapeHtmlMap = {
				'&': '&amp;',
				"'": '&#x27;',
				'`': '&#x60;',
				'"': '&quot;',
				'<': '&lt;',
				'>': '&gt;',
			};
    	
    	function invertEscapeMap(map) {
    		var output = {};
    		for (var key in map) {
    			var value = map[key];
    			output[value] = key;
    		};
    		return output;
    	};
    	
    	var unescapeHtmlMap = invertEscapeMap(escapeHtmlMap);
    	
    	var service = {
    		xssReplace: function(str) {
    			if (angular.isString(str)) {
    				str = str.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    			}
    			return str;
    		},
    		getByteLength: function(str) {
    			return encodeURIComponent(str).replace(/%../g,"x").length;
    		},
    		escapeHtml: function(string) {
    			if(typeof string !== 'string') {
    				return string;
    			}
    			return string.replace(/[&'`"<>]/g, function(match) {
    				return escapeHtmlMap[match];
    			});
    		},
    		unescapeHtml: function(string) {
    			if(typeof string !== 'string') {
    				return string;
    			}
    			return string.replace(/[&'`"<>]/g, function(match) {
    				return unescapeHtmlMap[match];
    			});
    		}
    	};
    	
    	return service;
	}]);